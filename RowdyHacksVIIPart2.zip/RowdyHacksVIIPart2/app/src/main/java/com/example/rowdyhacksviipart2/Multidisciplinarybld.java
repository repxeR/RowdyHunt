package com.example.rowdyhacksviipart2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Multidisciplinarybld extends AppCompatActivity {

    private static final String pass = "to business";
    private static final String fail = "stagnant";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_multidisciplinarybld);

        //get button
        Button btnYes = findViewById(R.id.nextMSButton);
        //set button to do stuff. Here we're passing i n new instance of an onclick listener
        btnYes.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Log.d(pass, "User headed to Multidisciplinary next scene");
                //load map with JPL enabled
                opennextScreen();
                //ON yes we will swap scenes to the JPL riddle

            }
        });
    }
    private void opennextScreen() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}