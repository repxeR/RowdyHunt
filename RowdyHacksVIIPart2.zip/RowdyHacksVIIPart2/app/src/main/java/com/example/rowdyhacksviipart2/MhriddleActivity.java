package com.example.rowdyhacksviipart2;

import androidx.appcompat.app.AppCompatActivity;

import android.app.IntentService;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import nl.dionsegijn.konfetti.KonfettiView;
import nl.dionsegijn.konfetti.models.Shape;
import nl.dionsegijn.konfetti.models.Size;

public class MhriddleActivity extends AppCompatActivity {

    //Riddle answer string!
    public static final String ANSWER = "General Posting Board";
    private KonfettiView celebrationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mhriddle);{
            @Override
            public void onClick(View v){
                celebrationView.build()
                        .addColors(Color.RED, Color.GREEN, Color.MAGENTA, Color.YELLOW)
                        .setDirection(0.0, 359.0)
                        .setSpeed(1f, 5f)
                        .setFadeOutEnabled(true)
                        .setTimeToLive(2000L)
                        .addShapes(Shape.RECT, Shape.CIRCLE)
                        .addSizes(new Size(12, 5))
                        .setPosition(-50f, celebrationView.getWidth() + 50f, -50f, -50f)
                        .streamFor(300, 5000L);

            }
        });

    }
    //Show hint 1 && change opacity button 2
    public void changeOpacityBtn2(View view){
        TextView hint1 = findViewById(R.id.hint1Txt);
        Button btn2 = findViewById(R.id.button2);
        hint1.setAlpha(1);
        btn2.setAlpha(1);
    }

    //Show hint 2 && change opacity button 3
    public void changeOpacityBtn3(View view){
        TextView hint2 = findViewById(R.id.hint2Txt);
        Button btn3 = findViewById(R.id.button3);
        btn3.setAlpha(1);
        hint2.setAlpha(1);

    }

    //shows hint 3
    public void showHint3(View view){
        TextView hint3 = findViewById(R.id.hint3Txt);
        hint3.setAlpha(1);
    }


    private void opennextScreen() {
        EditText answer = findViewById(R.id.userInput);

        Intent intent = new Intent(this, MhriddleActivity.class);
        startActivity(intent);
    }

    //I tried implementing a sleep function to call for delays when showing hints /  next buttons
    //it wasnt working properly
    public void sleep(int x){
        try {
            // to sleep 10 seconds
            Thread.sleep(x);
        } catch (InterruptedException e) {
            // recommended because catching InterruptedException clears interrupt flag
            Thread.currentThread().interrupt();
            // you probably want to quit if the thread is interrupted
            return;
        }
    }
}